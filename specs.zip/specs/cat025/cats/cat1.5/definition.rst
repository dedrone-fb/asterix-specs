Asterix category 025 - CNS/ATM Ground System Status Reports
===========================================================
**category**: 025

**edition**: 1.5

**date**: 2021-07-01

Preamble
--------
Surveillance data exchange.

Description of standard data items
----------------------------------

I025/000 - Report Type
**********************

*Definition*: This Data Item allows for a more convenient handling of the reports at the
receiver side by further defining the type of transaction.

*Structure*:

    **I025/000/RTYP** - *Report Type*

    - 7 bits [``.......``]

    - raw value

    **I025/000/RG** - *Report Generation*

    - 1 bit [``.``]

    - values:

        | 0: Periodic Report
        | 1: Event Driven Report

Notes:

    1. In applications where transactions of various types are exchanged,
       the Report Type Data Item facilitates the proper report handling at
       the receiver side.
    2. All Report Type values are reserved for common standard use.
    3. The following set of Report Types are standardised for Category 025 records:
        • 001 Service and System Status report (see 4.5.1.1. above)
        • 002 Component Status report (see 4.5.1.2. above)
        • 003 Service Statistics report (see 4.5.1.3. above)
    4. The list of items present for the three report types is defined in the
       following table.
       M stands for mandatory, O for optional, X for never present. ::

        Item        001                 002             003
        I025/000    M                   M               M
        I025/010    M                   M               M
        I025/015    M                   X               M
        I025/020    O                   X               O
        I025/070    M                   M               M
        I025/100    O                   X               X
        I025/105    O                   X               X
        I025/120    O                   M               X
        I025/140    X                   X               M
        I025/200    O                   O               O
        I025/600    O (See Note)        O               X
        I025/610    O (See Note)        O               X

    5. With Edition 1.3 of this specification the Encoding Rules for Data
       Item I025/600 and I025/610 in Message Type 001 have been changed
       from “Mandatory” to “Optional”. Before changing the data source such
       that the encoding of these Data Items is changed from “included” to
       “not included” it needs to be ensured that downstream systems do not
       apply “Mandatory Item Checks”. Otherwise this may lead to suppression
       of the Category 025 Record by the receiving system.

I025/010 - Data Source Identifier
*********************************

*Definition*: Identification of the Ground System from which the data is received.

*Structure*:

    **I025/010/SAC** - *System Area Code*

    - 8 bits [``........``]

    - raw value

    **I025/010/SIC** - *System Identification Code*

    - 8 bits [``........``]

    - raw value

Notes:

    1. The up-to-date list of SACs is published on the EUROCONTROL Web Site
       (http://www.eurocontrol.int/asterix).
    2. The SICs are allocated by the national authority responsible for the
       surveillance infrastructure.

I025/015 - Service Identification
*********************************

*Definition*: Identifies the service being reported.

*Structure*:

- 8 bits [``........``]

- raw value

Note:
    - The service identification is allocated by the system.

I025/020 - Service Designator
*****************************

*Definition*: Designator of the service being reported.

*Structure*:

- 48 bits [``... 48 bits ...``]

- ICAO string (6-bits per character)

Notes:

    1. bits-48/1 Service Designator. Characters 1-8 (coded on 6 Bits each)
       defining the text readable designator for each Service.
       Each character of the service designator is encoded as defined below
       (see ICAO Annex 10, Volume IV, page 3-77, table 3-9): ::


        .   .   .   .   b6  0   0   1   1
        .   .   .   .   b5  0   1   0   1
        b4  b3  b2  b1
        0   0   0   0           P   SP  0
        0   0   0   1       A   Q       1
        0   0   1   0       B   R       2
        0   0   1   1       C   S       3
        0   1   0   0       D   T       4
        0   1   0   1       E   U       5
        0   1   1   0       F   V       6
        0   1   1   1       G   W       7
        1   0   0   0       H   X       8
        1   0   0   1       I   Y       9
        1   0   1   0       J   Z
        1   0   1   1       K
        1   1   0   0       L
        1   1   0   1       M
        1   1   1   0       N
        1   1   1   1       O

    SP 1 = SPACE code
    For each character the following bit numbering convention shall be observed:

        b6 b5 b4 b3 b2 b1

    2. Assignments of Service designators to specific services/systems and
       interpretation of these fields are implementation dependent.
    3. Examples of Service Designators are “1090ADSB”, “WAM”, “1090TISB”, etc.
    4. Multiple Service Type Designators may be used to describe a single
       service where applicable

I025/070 - Time of Day
**********************

*Definition*: Absolute time stamping expressed as UTC time.

*Structure*:

- 24 bits [``........................``]

- unsigned quantity
- scaling factor: 1
- fractional bits: 7
- unit: "s"
- LSB = :math:`1 / {2^{7}}` s = :math:`1 / {128}` s :math:`\approx 7.8125e-3` s

Note:
    - The time of day value is reset to zero each day at midnight.

I025/100 - System and Service Status
************************************

*Definition*: Information concerning the status of the Service Volume.

*Structure*:

Extended item.

    **I025/100/NOGO**

    - 1 bit [``.``]

    - values:

        | 0: Data is released for operational use
        | 1: Data must not be used operationally

    **I025/100/OPS**

    - 2 bits [``..``]

    - values:

        | 0: Operational
        | 1: Operational but in Standby
        | 2: Maintenance
        | 3: Reserved for future use

    **I025/100/SSTAT**

    - 4 bits [``....``]

    - values:

        | 0: Running
        | 1: Failed
        | 2: Degraded
        | 3: Undefined
        | 4: Reserved for future use
        | 5: Reserved for future use
        | 6: Reserved for future use
        | 7: Reserved for future use
        | 8: Reserved for future use
        | 9: Reserved for future use
        | 10: Reserved for future use
        | 11: Reserved for future use
        | 12: Reserved for future use
        | 13: Reserved for future use
        | 14: Reserved for future use
        | 15: Reserved for future use

    ``(FX)``

    - extension bit

        | 0: End of data item
        | 1: Extension into next extent

    **I025/100/(spare)**

    - 1 bit [``.``]

    **I025/100/SYSTAT**

    - 3 bits [``...``]

    - values:

        | 0: Running / OK
        | 1: Failed
        | 2: Degraded
        | 3: Undefined
        | 4: Reserved for future use
        | 5: Reserved for future use
        | 6: Reserved for future use
        | 7: Reserved for future use

    **I025/100/SESTAT**

    - 3 bits [``...``]

    - values:

        | 0: OK
        | 1: Failed
        | 2: Degraded
        | 3: Undefined
        | 4: Reserved for future use
        | 5: Reserved for future use
        | 6: Reserved for future use
        | 7: Reserved for future use

    ``(FX)``

    - extension bit

        | 0: End of data item
        | 1: Extension into next extent

Notes:

    1. Bit 8 (NOGO), when set to “1” indicates that the data transmitted
       by the system/service is not released for operational use. This
       indication is independent from the status of the system itself or
       that of the service. It just indicates that the system or service
       volume output must not be used for operational services but may be
       used for, e.g. test and validation purposes. The indication GO/NO-GO
       indicates a mode of the system rather than a status. Usually this bit
       will be set by operator input.
    2. Bit 7/6 (OPS), when set to “1” indicates that the service is running
       but not operationally used (e.g. for a standby system in a redundant configuration).
    3. Bits 5/2 (SSTAT): This information informs about the state of the
       overall service volume status. The actual implementation of this
       field is service dependent and should be described in the system/service
       specification. However, it is expected that – as far as this information
       is available – a mapping is performed between the states of individual
       components as reported in data item I025/120. As an example, if one
       component fails but the system is still operational (at least partially),
       the service status should change to “Degraded”.
    4. To bit 7 (ERR): This bit set to “1” indicates that the range of the
       target is beyond the maximum range in data item I048/040.In this
       case – and this case only - the ERR Data Item in the Reserved
       Expansion Field shall provide the range value of the Measured
       Position in Polar Coordinates.
    5. This octet allows to separate reporting of the system and the service
       status as in particular in distributed systems it is possible that
       the degraded system state may not have an impact on the service state.
       For reasons of backwards compatibility (for systems that are not yet
       capable to decode the first extension), the system and service status
       shall be propagated to the field SSTAT in the primary part of I025/100,
       bits 5/2 according to the following table: ::

        SeSTAT  SySTAT  SSTAT

        0       0       0
        0       1       1
        0       2       2
        0       3       1
        1       0       1
        1       1       1
        1       2       1
        1       3       1
        2       0       2
        2       1       1
        2       2       2
        2       3       1
        3       0       1
        3       1       1
        3       2       1
        3       3       1

       The value of 3 'Undefined' is assumed to represent that the status
       cannot be determined. This inherently indicates a failure in system
       monitoring. Therefore, a value of 3 'Undefined' is equivalent to 1
       'Failed', leading to rejection of data and prompting maintenance/operator
       investigation to occur.

       The population of SSTAT is determined to be the worst-case combination
       of SeSTAT and SySTAT, taking into account Note 1, where the hierarchy
       of best to worst case is as follows: Running, Degraded, Failed.

I025/105 - System and Service Error Codes
*****************************************

*Definition*: Error Status of the System and the Service.

*Structure*:

Repetitive item, repetition factor 8 bits.

    - 8 bits [``........``]

    - values:

        | 0: No error detected (shall not be sent)
        | 1: Error Code Undefined
        | 2: Time Source Invalid
        | 3: Time Source Coasting
        | 4: Track ID numbering has restarted
        | 5: Data Processor Overload
        | 6: Ground Interface Data Communications Overload
        | 7: System stopped by operator
        | 8: CBIT failed
        | 9: Test Target Failure
        | 10: Reserved for allocation by the AMG
        | 11: Reserved for allocation by the AMG
        | 12: Reserved for allocation by the AMG
        | 13: Reserved for allocation by the AMG
        | 14: Reserved for allocation by the AMG
        | 15: Reserved for allocation by the AMG
        | 16: Reserved for allocation by the AMG
        | 17: Reserved for allocation by the AMG
        | 18: Reserved for allocation by the AMG
        | 19: Reserved for allocation by the AMG
        | 20: Reserved for allocation by the AMG
        | 21: Reserved for allocation by the AMG
        | 22: Reserved for allocation by the AMG
        | 23: Reserved for allocation by the AMG
        | 24: Reserved for allocation by the AMG
        | 25: Reserved for allocation by the AMG
        | 26: Reserved for allocation by the AMG
        | 27: Reserved for allocation by the AMG
        | 28: Reserved for allocation by the AMG
        | 29: Reserved for allocation by the AMG
        | 30: Reserved for allocation by the AMG
        | 31: Reserved for allocation by the AMG
        | 32: Reserved for allocation by system manufacturers
        | 33: Reserved for allocation by system manufacturers
        | 34: Reserved for allocation by system manufacturers
        | 35: Reserved for allocation by system manufacturers
        | 36: Reserved for allocation by system manufacturers
        | 37: Reserved for allocation by system manufacturers
        | 38: Reserved for allocation by system manufacturers
        | 39: Reserved for allocation by system manufacturers
        | 40: Reserved for allocation by system manufacturers
        | 41: Reserved for allocation by system manufacturers
        | 42: Reserved for allocation by system manufacturers
        | 43: Reserved for allocation by system manufacturers
        | 44: Reserved for allocation by system manufacturers
        | 45: Reserved for allocation by system manufacturers
        | 46: Reserved for allocation by system manufacturers
        | 47: Reserved for allocation by system manufacturers
        | 48: Reserved for allocation by system manufacturers
        | 49: Reserved for allocation by system manufacturers
        | 50: Reserved for allocation by system manufacturers
        | 51: Reserved for allocation by system manufacturers
        | 52: Reserved for allocation by system manufacturers
        | 53: Reserved for allocation by system manufacturers
        | 54: Reserved for allocation by system manufacturers
        | 55: Reserved for allocation by system manufacturers
        | 56: Reserved for allocation by system manufacturers
        | 57: Reserved for allocation by system manufacturers
        | 58: Reserved for allocation by system manufacturers
        | 59: Reserved for allocation by system manufacturers
        | 60: Reserved for allocation by system manufacturers
        | 61: Reserved for allocation by system manufacturers
        | 62: Reserved for allocation by system manufacturers
        | 63: Reserved for allocation by system manufacturers
        | 64: Reserved for allocation by system manufacturers
        | 65: Reserved for allocation by system manufacturers
        | 66: Reserved for allocation by system manufacturers
        | 67: Reserved for allocation by system manufacturers
        | 68: Reserved for allocation by system manufacturers
        | 69: Reserved for allocation by system manufacturers
        | 70: Reserved for allocation by system manufacturers
        | 71: Reserved for allocation by system manufacturers
        | 72: Reserved for allocation by system manufacturers
        | 73: Reserved for allocation by system manufacturers
        | 74: Reserved for allocation by system manufacturers
        | 75: Reserved for allocation by system manufacturers
        | 76: Reserved for allocation by system manufacturers
        | 77: Reserved for allocation by system manufacturers
        | 78: Reserved for allocation by system manufacturers
        | 79: Reserved for allocation by system manufacturers
        | 80: Reserved for allocation by system manufacturers
        | 81: Reserved for allocation by system manufacturers
        | 82: Reserved for allocation by system manufacturers
        | 83: Reserved for allocation by system manufacturers
        | 84: Reserved for allocation by system manufacturers
        | 85: Reserved for allocation by system manufacturers
        | 86: Reserved for allocation by system manufacturers
        | 87: Reserved for allocation by system manufacturers
        | 88: Reserved for allocation by system manufacturers
        | 89: Reserved for allocation by system manufacturers
        | 90: Reserved for allocation by system manufacturers
        | 91: Reserved for allocation by system manufacturers
        | 92: Reserved for allocation by system manufacturers
        | 93: Reserved for allocation by system manufacturers
        | 94: Reserved for allocation by system manufacturers
        | 95: Reserved for allocation by system manufacturers
        | 96: Reserved for allocation by system manufacturers
        | 97: Reserved for allocation by system manufacturers
        | 98: Reserved for allocation by system manufacturers
        | 99: Reserved for allocation by system manufacturers
        | 100: Reserved for allocation by system manufacturers
        | 101: Reserved for allocation by system manufacturers
        | 102: Reserved for allocation by system manufacturers
        | 103: Reserved for allocation by system manufacturers
        | 104: Reserved for allocation by system manufacturers
        | 105: Reserved for allocation by system manufacturers
        | 106: Reserved for allocation by system manufacturers
        | 107: Reserved for allocation by system manufacturers
        | 108: Reserved for allocation by system manufacturers
        | 109: Reserved for allocation by system manufacturers
        | 110: Reserved for allocation by system manufacturers
        | 111: Reserved for allocation by system manufacturers
        | 112: Reserved for allocation by system manufacturers
        | 113: Reserved for allocation by system manufacturers
        | 114: Reserved for allocation by system manufacturers
        | 115: Reserved for allocation by system manufacturers
        | 116: Reserved for allocation by system manufacturers
        | 117: Reserved for allocation by system manufacturers
        | 118: Reserved for allocation by system manufacturers
        | 119: Reserved for allocation by system manufacturers
        | 120: Reserved for allocation by system manufacturers
        | 121: Reserved for allocation by system manufacturers
        | 122: Reserved for allocation by system manufacturers
        | 123: Reserved for allocation by system manufacturers
        | 124: Reserved for allocation by system manufacturers
        | 125: Reserved for allocation by system manufacturers
        | 126: Reserved for allocation by system manufacturers
        | 127: Reserved for allocation by system manufacturers
        | 128: Reserved for allocation by system manufacturers
        | 129: Reserved for allocation by system manufacturers
        | 130: Reserved for allocation by system manufacturers
        | 131: Reserved for allocation by system manufacturers
        | 132: Reserved for allocation by system manufacturers
        | 133: Reserved for allocation by system manufacturers
        | 134: Reserved for allocation by system manufacturers
        | 135: Reserved for allocation by system manufacturers
        | 136: Reserved for allocation by system manufacturers
        | 137: Reserved for allocation by system manufacturers
        | 138: Reserved for allocation by system manufacturers
        | 139: Reserved for allocation by system manufacturers
        | 140: Reserved for allocation by system manufacturers
        | 141: Reserved for allocation by system manufacturers
        | 142: Reserved for allocation by system manufacturers
        | 143: Reserved for allocation by system manufacturers
        | 144: Reserved for allocation by system manufacturers
        | 145: Reserved for allocation by system manufacturers
        | 146: Reserved for allocation by system manufacturers
        | 147: Reserved for allocation by system manufacturers
        | 148: Reserved for allocation by system manufacturers
        | 149: Reserved for allocation by system manufacturers
        | 150: Reserved for allocation by system manufacturers
        | 151: Reserved for allocation by system manufacturers
        | 152: Reserved for allocation by system manufacturers
        | 153: Reserved for allocation by system manufacturers
        | 154: Reserved for allocation by system manufacturers
        | 155: Reserved for allocation by system manufacturers
        | 156: Reserved for allocation by system manufacturers
        | 157: Reserved for allocation by system manufacturers
        | 158: Reserved for allocation by system manufacturers
        | 159: Reserved for allocation by system manufacturers
        | 160: Reserved for allocation by system manufacturers
        | 161: Reserved for allocation by system manufacturers
        | 162: Reserved for allocation by system manufacturers
        | 163: Reserved for allocation by system manufacturers
        | 164: Reserved for allocation by system manufacturers
        | 165: Reserved for allocation by system manufacturers
        | 166: Reserved for allocation by system manufacturers
        | 167: Reserved for allocation by system manufacturers
        | 168: Reserved for allocation by system manufacturers
        | 169: Reserved for allocation by system manufacturers
        | 170: Reserved for allocation by system manufacturers
        | 171: Reserved for allocation by system manufacturers
        | 172: Reserved for allocation by system manufacturers
        | 173: Reserved for allocation by system manufacturers
        | 174: Reserved for allocation by system manufacturers
        | 175: Reserved for allocation by system manufacturers
        | 176: Reserved for allocation by system manufacturers
        | 177: Reserved for allocation by system manufacturers
        | 178: Reserved for allocation by system manufacturers
        | 179: Reserved for allocation by system manufacturers
        | 180: Reserved for allocation by system manufacturers
        | 181: Reserved for allocation by system manufacturers
        | 182: Reserved for allocation by system manufacturers
        | 183: Reserved for allocation by system manufacturers
        | 184: Reserved for allocation by system manufacturers
        | 185: Reserved for allocation by system manufacturers
        | 186: Reserved for allocation by system manufacturers
        | 187: Reserved for allocation by system manufacturers
        | 188: Reserved for allocation by system manufacturers
        | 189: Reserved for allocation by system manufacturers
        | 190: Reserved for allocation by system manufacturers
        | 191: Reserved for allocation by system manufacturers
        | 192: Reserved for allocation by system manufacturers
        | 193: Reserved for allocation by system manufacturers
        | 194: Reserved for allocation by system manufacturers
        | 195: Reserved for allocation by system manufacturers
        | 196: Reserved for allocation by system manufacturers
        | 197: Reserved for allocation by system manufacturers
        | 198: Reserved for allocation by system manufacturers
        | 199: Reserved for allocation by system manufacturers
        | 200: Reserved for allocation by system manufacturers
        | 201: Reserved for allocation by system manufacturers
        | 202: Reserved for allocation by system manufacturers
        | 203: Reserved for allocation by system manufacturers
        | 204: Reserved for allocation by system manufacturers
        | 205: Reserved for allocation by system manufacturers
        | 206: Reserved for allocation by system manufacturers
        | 207: Reserved for allocation by system manufacturers
        | 208: Reserved for allocation by system manufacturers
        | 209: Reserved for allocation by system manufacturers
        | 210: Reserved for allocation by system manufacturers
        | 211: Reserved for allocation by system manufacturers
        | 212: Reserved for allocation by system manufacturers
        | 213: Reserved for allocation by system manufacturers
        | 214: Reserved for allocation by system manufacturers
        | 215: Reserved for allocation by system manufacturers
        | 216: Reserved for allocation by system manufacturers
        | 217: Reserved for allocation by system manufacturers
        | 218: Reserved for allocation by system manufacturers
        | 219: Reserved for allocation by system manufacturers
        | 220: Reserved for allocation by system manufacturers
        | 221: Reserved for allocation by system manufacturers
        | 222: Reserved for allocation by system manufacturers
        | 223: Reserved for allocation by system manufacturers
        | 224: Reserved for allocation by system manufacturers
        | 225: Reserved for allocation by system manufacturers
        | 226: Reserved for allocation by system manufacturers
        | 227: Reserved for allocation by system manufacturers
        | 228: Reserved for allocation by system manufacturers
        | 229: Reserved for allocation by system manufacturers
        | 230: Reserved for allocation by system manufacturers
        | 231: Reserved for allocation by system manufacturers
        | 232: Reserved for allocation by system manufacturers
        | 233: Reserved for allocation by system manufacturers
        | 234: Reserved for allocation by system manufacturers
        | 235: Reserved for allocation by system manufacturers
        | 236: Reserved for allocation by system manufacturers
        | 237: Reserved for allocation by system manufacturers
        | 238: Reserved for allocation by system manufacturers
        | 239: Reserved for allocation by system manufacturers
        | 240: Reserved for allocation by system manufacturers
        | 241: Reserved for allocation by system manufacturers
        | 242: Reserved for allocation by system manufacturers
        | 243: Reserved for allocation by system manufacturers
        | 244: Reserved for allocation by system manufacturers
        | 245: Reserved for allocation by system manufacturers
        | 246: Reserved for allocation by system manufacturers
        | 247: Reserved for allocation by system manufacturers
        | 248: Reserved for allocation by system manufacturers
        | 249: Reserved for allocation by system manufacturers
        | 250: Reserved for allocation by system manufacturers
        | 251: Reserved for allocation by system manufacturers
        | 252: Reserved for allocation by system manufacturers
        | 253: Reserved for allocation by system manufacturers
        | 254: Reserved for allocation by system manufacturers
        | 255: Reserved for allocation by system manufacturers

Notes:

    1. The Warning & Error codes contain information about the reason why
       the System and Service State (SSTAT in item I025/100) is different
       from “running”.
    2. A time source is considered as valid when either externally synchronised
       or running on a local oscillator within the required accuracy of UTC.
    3. A value of 4 indicates that the allocation of Track-IDs was re-started.
    4. Multiple error codes can be transmitted within the same ASTERIX record.
    5. Error codes in the range 0 to 31 shall be allocated centrally by
       the AMG. Error codes in the range from 32 to 255 are available for
       specification by the system manufacturers. They are not standardised
       and shall be described in the Interface Control Document (ICD) of the
       respective system.

I025/120 - Component Status
***************************

*Definition*: Indications of status of various system components and, when applicable, error codes.

*Structure*:

Repetitive item, repetition factor 8 bits.

        **I025/120/CID** - *Component ID*

        - 16 bits [``................``]

        - raw value

        **I025/120/ERRC** - *Error Code*

        - 6 bits [``......``]

        - values:

            | 0: No Error Detected
            | 1: Error Code Undefined
            | 2: Reserved for allocation by the AMG
            | 3: Reserved for allocation by the AMG
            | 4: Reserved for allocation by the AMG
            | 5: Reserved for allocation by the AMG
            | 6: Reserved for allocation by the AMG
            | 7: Reserved for allocation by the AMG
            | 8: Reserved for allocation by the AMG
            | 9: Reserved for allocation by the AMG
            | 10: Reserved for allocation by the AMG
            | 11: Reserved for allocation by the AMG
            | 12: Reserved for allocation by the AMG
            | 13: Reserved for allocation by the AMG
            | 14: Reserved for allocation by the AMG
            | 15: Reserved for allocation by the AMG
            | 16: Reserved for allocation by system manufacturers
            | 17: Reserved for allocation by system manufacturers
            | 18: Reserved for allocation by system manufacturers
            | 19: Reserved for allocation by system manufacturers
            | 20: Reserved for allocation by system manufacturers
            | 21: Reserved for allocation by system manufacturers
            | 22: Reserved for allocation by system manufacturers
            | 23: Reserved for allocation by system manufacturers
            | 24: Reserved for allocation by system manufacturers
            | 25: Reserved for allocation by system manufacturers
            | 26: Reserved for allocation by system manufacturers
            | 27: Reserved for allocation by system manufacturers
            | 28: Reserved for allocation by system manufacturers
            | 29: Reserved for allocation by system manufacturers
            | 30: Reserved for allocation by system manufacturers
            | 31: Reserved for allocation by system manufacturers
            | 32: Reserved for allocation by system manufacturers
            | 33: Reserved for allocation by system manufacturers
            | 34: Reserved for allocation by system manufacturers
            | 35: Reserved for allocation by system manufacturers
            | 36: Reserved for allocation by system manufacturers
            | 37: Reserved for allocation by system manufacturers
            | 38: Reserved for allocation by system manufacturers
            | 39: Reserved for allocation by system manufacturers
            | 40: Reserved for allocation by system manufacturers
            | 41: Reserved for allocation by system manufacturers
            | 42: Reserved for allocation by system manufacturers
            | 43: Reserved for allocation by system manufacturers
            | 44: Reserved for allocation by system manufacturers
            | 45: Reserved for allocation by system manufacturers
            | 46: Reserved for allocation by system manufacturers
            | 47: Reserved for allocation by system manufacturers
            | 48: Reserved for allocation by system manufacturers
            | 49: Reserved for allocation by system manufacturers
            | 50: Reserved for allocation by system manufacturers
            | 51: Reserved for allocation by system manufacturers
            | 52: Reserved for allocation by system manufacturers
            | 53: Reserved for allocation by system manufacturers
            | 54: Reserved for allocation by system manufacturers
            | 55: Reserved for allocation by system manufacturers
            | 56: Reserved for allocation by system manufacturers
            | 57: Reserved for allocation by system manufacturers
            | 58: Reserved for allocation by system manufacturers
            | 59: Reserved for allocation by system manufacturers
            | 60: Reserved for allocation by system manufacturers
            | 61: Reserved for allocation by system manufacturers
            | 62: Reserved for allocation by system manufacturers
            | 63: Reserved for allocation by system manufacturers

        **I025/120/CS** - *Component State/Mode*

        - 2 bits [``..``]

        - values:

            | 0: Running
            | 1: Failed
            | 2: Maintenance
            | 3: Reserved

Note:
    - Error codes in the range 2 to 15 shall be allocated centrally by the
      AMG. Error codes in the range from 16 to 63 are available for
      specification by the system manufacturers. They are not standardised
      and shall be described in the Interface Control Document (ICD) of the
      respective system.

I025/140 - Service Statistics
*****************************

*Definition*: Statistics concerning the service. Provides counts of various message types
that have been received since the report was last sent.

*Structure*:

Repetitive item, repetition factor 8 bits.

        **I025/140/TYPE** - *Type of Report Counter*

        - 8 bits [``........``]

        - values:

            | 0: Number of unknown messages received
            | 1: Number of too old messages received
            | 2: Number of failed message conversions
            | 3: Total Number of messages received
            | 4: Total number of messages transmitted
            | 5: Reserved for AMG
            | 6: Reserved for AMG
            | 7: Reserved for AMG
            | 8: Reserved for AMG
            | 9: Reserved for AMG
            | 10: Reserved for AMG
            | 11: Reserved for AMG
            | 12: Reserved for AMG
            | 13: Reserved for AMG
            | 14: Reserved for AMG
            | 15: Reserved for AMG
            | 16: Reserved for AMG
            | 17: Reserved for AMG
            | 18: Reserved for AMG
            | 19: Reserved for AMG
            | 20: Implementation specific
            | 21: Implementation specific
            | 22: Implementation specific
            | 23: Implementation specific
            | 24: Implementation specific
            | 25: Implementation specific
            | 26: Implementation specific
            | 27: Implementation specific
            | 28: Implementation specific
            | 29: Implementation specific
            | 30: Implementation specific
            | 31: Implementation specific
            | 32: Implementation specific
            | 33: Implementation specific
            | 34: Implementation specific
            | 35: Implementation specific
            | 36: Implementation specific
            | 37: Implementation specific
            | 38: Implementation specific
            | 39: Implementation specific
            | 40: Implementation specific
            | 41: Implementation specific
            | 42: Implementation specific
            | 43: Implementation specific
            | 44: Implementation specific
            | 45: Implementation specific
            | 46: Implementation specific
            | 47: Implementation specific
            | 48: Implementation specific
            | 49: Implementation specific
            | 50: Implementation specific
            | 51: Implementation specific
            | 52: Implementation specific
            | 53: Implementation specific
            | 54: Implementation specific
            | 55: Implementation specific
            | 56: Implementation specific
            | 57: Implementation specific
            | 58: Implementation specific
            | 59: Implementation specific
            | 60: Implementation specific
            | 61: Implementation specific
            | 62: Implementation specific
            | 63: Implementation specific
            | 64: Implementation specific
            | 65: Implementation specific
            | 66: Implementation specific
            | 67: Implementation specific
            | 68: Implementation specific
            | 69: Implementation specific
            | 70: Implementation specific
            | 71: Implementation specific
            | 72: Implementation specific
            | 73: Implementation specific
            | 74: Implementation specific
            | 75: Implementation specific
            | 76: Implementation specific
            | 77: Implementation specific
            | 78: Implementation specific
            | 79: Implementation specific
            | 80: Implementation specific
            | 81: Implementation specific
            | 82: Implementation specific
            | 83: Implementation specific
            | 84: Implementation specific
            | 85: Implementation specific
            | 86: Implementation specific
            | 87: Implementation specific
            | 88: Implementation specific
            | 89: Implementation specific
            | 90: Implementation specific
            | 91: Implementation specific
            | 92: Implementation specific
            | 93: Implementation specific
            | 94: Implementation specific
            | 95: Implementation specific
            | 96: Implementation specific
            | 97: Implementation specific
            | 98: Implementation specific
            | 99: Implementation specific
            | 100: Implementation specific
            | 101: Implementation specific
            | 102: Implementation specific
            | 103: Implementation specific
            | 104: Implementation specific
            | 105: Implementation specific
            | 106: Implementation specific
            | 107: Implementation specific
            | 108: Implementation specific
            | 109: Implementation specific
            | 110: Implementation specific
            | 111: Implementation specific
            | 112: Implementation specific
            | 113: Implementation specific
            | 114: Implementation specific
            | 115: Implementation specific
            | 116: Implementation specific
            | 117: Implementation specific
            | 118: Implementation specific
            | 119: Implementation specific
            | 120: Implementation specific
            | 121: Implementation specific
            | 122: Implementation specific
            | 123: Implementation specific
            | 124: Implementation specific
            | 125: Implementation specific
            | 126: Implementation specific
            | 127: Implementation specific
            | 128: Implementation specific
            | 129: Implementation specific
            | 130: Implementation specific
            | 131: Implementation specific
            | 132: Implementation specific
            | 133: Implementation specific
            | 134: Implementation specific
            | 135: Implementation specific
            | 136: Implementation specific
            | 137: Implementation specific
            | 138: Implementation specific
            | 139: Implementation specific
            | 140: Implementation specific
            | 141: Implementation specific
            | 142: Implementation specific
            | 143: Implementation specific
            | 144: Implementation specific
            | 145: Implementation specific
            | 146: Implementation specific
            | 147: Implementation specific
            | 148: Implementation specific
            | 149: Implementation specific
            | 150: Implementation specific
            | 151: Implementation specific
            | 152: Implementation specific
            | 153: Implementation specific
            | 154: Implementation specific
            | 155: Implementation specific
            | 156: Implementation specific
            | 157: Implementation specific
            | 158: Implementation specific
            | 159: Implementation specific
            | 160: Implementation specific
            | 161: Implementation specific
            | 162: Implementation specific
            | 163: Implementation specific
            | 164: Implementation specific
            | 165: Implementation specific
            | 166: Implementation specific
            | 167: Implementation specific
            | 168: Implementation specific
            | 169: Implementation specific
            | 170: Implementation specific
            | 171: Implementation specific
            | 172: Implementation specific
            | 173: Implementation specific
            | 174: Implementation specific
            | 175: Implementation specific
            | 176: Implementation specific
            | 177: Implementation specific
            | 178: Implementation specific
            | 179: Implementation specific
            | 180: Implementation specific
            | 181: Implementation specific
            | 182: Implementation specific
            | 183: Implementation specific
            | 184: Implementation specific
            | 185: Implementation specific
            | 186: Implementation specific
            | 187: Implementation specific
            | 188: Implementation specific
            | 189: Implementation specific
            | 190: Implementation specific
            | 191: Implementation specific
            | 192: Implementation specific
            | 193: Implementation specific
            | 194: Implementation specific
            | 195: Implementation specific
            | 196: Implementation specific
            | 197: Implementation specific
            | 198: Implementation specific
            | 199: Implementation specific
            | 200: Implementation specific
            | 201: Implementation specific
            | 202: Implementation specific
            | 203: Implementation specific
            | 204: Implementation specific
            | 205: Implementation specific
            | 206: Implementation specific
            | 207: Implementation specific
            | 208: Implementation specific
            | 209: Implementation specific
            | 210: Implementation specific
            | 211: Implementation specific
            | 212: Implementation specific
            | 213: Implementation specific
            | 214: Implementation specific
            | 215: Implementation specific
            | 216: Implementation specific
            | 217: Implementation specific
            | 218: Implementation specific
            | 219: Implementation specific
            | 220: Implementation specific
            | 221: Implementation specific
            | 222: Implementation specific
            | 223: Implementation specific
            | 224: Implementation specific
            | 225: Implementation specific
            | 226: Implementation specific
            | 227: Implementation specific
            | 228: Implementation specific
            | 229: Implementation specific
            | 230: Implementation specific
            | 231: Implementation specific
            | 232: Implementation specific
            | 233: Implementation specific
            | 234: Implementation specific
            | 235: Implementation specific
            | 236: Implementation specific
            | 237: Implementation specific
            | 238: Implementation specific
            | 239: Implementation specific
            | 240: Implementation specific
            | 241: Implementation specific
            | 242: Implementation specific
            | 243: Implementation specific
            | 244: Implementation specific
            | 245: Implementation specific
            | 246: Implementation specific
            | 247: Implementation specific
            | 248: Implementation specific
            | 249: Implementation specific
            | 250: Implementation specific
            | 251: Implementation specific
            | 252: Implementation specific
            | 253: Implementation specific
            | 254: Implementation specific
            | 255: Implementation specific

        **I025/140/REF** - *Reference from which the Messages Are Counted*

        - 1 bit [``.``]

        - values:

            | 0: From UTC midnight
            | 1: From the previous report

        **I025/140/(spare)**

        - 7 bits [``.......``]

        **I025/140/COUNT** - *Counter Value*

        - 32 bits [``................................``]

        - unsigned integer

Note:
    - There is no special significance attributed to the numbering of the
      TYPE field. However the range from 0 to 19 is intended to cover
      generic messages which may be applicable to many types of service.

I025/200 - Message Identification
*********************************

*Definition*: Identification of a unique message.

*Structure*:

- 24 bits [``........................``]

- unsigned integer

Notes:

    1. The Message Identification Number is to be used to uniquely identify
       each message. If messages are being sent on redundant links then this
       number shall be identical for the same message on each link. This will
       allow the receiver to easily identify and discard duplicate messages.
    2. It is not required that Message Identification Numbers be assigned in
       ascending order by time of message transmission.

I025/600 - Position of the System Reference Point
*************************************************

*Definition*: Position of the reference point in WGS-84 Coordinates.

*Structure*:

    **I025/600/LAT** - *Latitude*

    - 32 bits [``................................``]

    - signed quantity
    - scaling factor: 180
    - fractional bits: 32
    - unit: "°"
    - LSB = :math:`180 / {2^{32}}` ° = :math:`180 / {4294967296}` ° :math:`\approx 4.190951585769653e-8` °
    - value :math:`>= -90` °
    - value :math:`< 90` °

    **I025/600/LON** - *Longitude*

    - 32 bits [``................................``]

    - signed quantity
    - scaling factor: 180
    - fractional bits: 32
    - unit: "°"
    - LSB = :math:`180 / {2^{32}}` ° = :math:`180 / {4294967296}` ° :math:`\approx 4.190951585769653e-8` °
    - value :math:`>= -180` °
    - value :math:`< 180` °

Notes:

    - Positive longitude indicates East. Positive latitude indicates North.

I025/610 - Height of the System Reference Point
***********************************************

*Definition*: Height of the system reference point in two’s complement form. The height
shall use mean sea level as the zero reference level.

*Structure*:

- 16 bits [``................``]

- signed quantity
- scaling factor: 1
- fractional bits: 2
- unit: "m"
- LSB = :math:`1 / {2^{2}}` m = :math:`1 / {4}` m :math:`\approx 0.25` m
- value :math:`>= -8192` m
- value :math:`<= 8191.75` m

Notes:

    - Item I025/610 shall only be sent together with item I025/600 “Position
      of the System Reference Point”.

I025/SP - Special Purpose Field
*******************************

*Definition*: Special Purpose Field

*Structure*:

Explicit item (SP)

User Application Profile for Category 025
=========================================
- (1) ``I025/010`` - Data Source Identifier
- (2) ``I025/000`` - Report Type
- (3) ``I025/200`` - Message Identification
- (4) ``I025/015`` - Service Identification
- (5) ``I025/020`` - Service Designator
- (6) ``I025/070`` - Time of Day
- (7) ``I025/100`` - System and Service Status
- ``(FX)`` - Field extension indicator
- (8) ``I025/105`` - System and Service Error Codes
- (9) ``I025/120`` - Component Status
- (10) ``I025/140`` - Service Statistics
- (11) ``I025/SP`` - Special Purpose Field
- (12) ``I025/600`` - Position of the System Reference Point
- (13) ``I025/610`` - Height of the System Reference Point
- (14) ``(spare)``
- ``(FX)`` - Field extension indicator
